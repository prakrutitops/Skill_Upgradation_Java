package com.example.upim
import android.app.Activity
import android.content.ContentResolver
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import net.gotev.uploadservice.MultipartUploadRequest
import net.gotev.uploadservice.UploadServiceBroadcastReceiver
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var btnSelect: Button
    private lateinit var btnUpload: Button
    private lateinit var edtName: EditText
    private lateinit var imgView: ImageView
    private var selectedImageUri: Uri? = null
    private val PICK_IMAGE_REQUEST = 1
    private val UPLOAD_URL = "https://prakrutitech.buzz/CRUD/upload.php" // Replace with your server URL

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnSelect = findViewById(R.id.btn1)
        btnUpload = findViewById(R.id.btn2)
        edtName = findViewById(R.id.edt1)
        imgView = findViewById(R.id.img)

        // Select image
        btnSelect.setOnClickListener {
            openImagePicker()
        }

        // Upload image
        btnUpload.setOnClickListener {
            selectedImageUri?.let { uri ->
                val filePath = getRealPathFromURI(uri)
                if (filePath != null)
                {
                    Toast.makeText(applicationContext, "a", Toast.LENGTH_SHORT).show()
                    uploadImage(filePath)
                    Toast.makeText(applicationContext, "b", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // Open image picker to select an image
    private fun openImagePicker() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, PICK_IMAGE_REQUEST)
    }

    // Handle image selection result
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null) {
            selectedImageUri = data.data
            imgView.setImageURI(selectedImageUri)
        }
    }

    // Convert URI to file path
    private fun getRealPathFromURI(uri: Uri): String? {
        val cursor: Cursor? = contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            it.moveToFirst()
            val columnIndex = it.getColumnIndex(MediaStore.Images.Media.DATA)
            if (columnIndex != -1) {
                return it.getString(columnIndex)
            }
        }
        return null
    }

    // Upload image to server
    private fun uploadImage(filePath: String) {
        val name = edtName.text.toString()

        try {
            val uploadRequest = MultipartUploadRequest(this, UPLOAD_URL)
                .addFileToUpload(filePath, "url")  // "file" is the field name on the server
                .addParameter("name", name)         // Add additional parameters if needed
                .setMaxRetries(2)

            uploadRequest.startUpload()
            Toast.makeText(applicationContext, "success", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            e.printStackTrace()
            Log.e("Upload", "Upload failed: ${e.message}")
        }
    }
}
